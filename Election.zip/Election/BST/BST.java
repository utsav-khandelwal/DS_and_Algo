package col106.assignment3.BST;
import java.util.Queue;
import java.util.LinkedList;

public class BST<T extends Comparable, E extends Comparable> implements BSTInterface<T, E>  {
	/* 
	 * Do not touch the code inside the upcoming block 
	 * If anything tempered your marks will be directly cut to zero
	*/
	public static void main() {
		BSTDriverCode BDC = new BSTDriverCode();
		System.setOut(BDC.fileout());
	}
	/*
	 * end code
	 * start writing your code from here
	 */


	private node<T, E> root;

	private class node<T extends Comparable, E extends Comparable>{
		node<T,E> left;
		node<T,E> right;
		T key;
		E value;

		public node(T k, E v){
			key =k;
			value=v;
			left=null;
			right=null;
		}
	}


	public BST(){
		root=null;
	}

    public void insert(T key, E value) {
    	node<T, E> ptr;
    	ptr = root;
    	if(root == null)
    	{
    		root = new node(key,value);
    		return;
    	}
    	node <T,E>temp = ptr;
    	int counter = 0;
    	while (ptr!=null){
    		if (value.compareTo(ptr.value)>0){
    			temp = ptr;
    			ptr=ptr.right;
    			counter = 1;
    		}
    		else{
    			temp = ptr;
    			ptr = ptr.left;
    			counter = -1;
    		}
    	}
    	if(counter == 1)
    	{
    		temp.right = new node(key,value);
    	}
    	else
    	{
    		temp.left = new node(key,value);
    	}
    	return;
    	// System.out.println("Inserting: " + key + ", " + value);
    }

    public void update(T key, E value) {
    	// include a condition for when root is null

    	node<T,E> upd_node = find(key, root);
    	delete(key);
    	insert(key, value);

    	// System.out.println("Updating key "+ key = " to value " + value);
    }

    public void delete(T key){
    	node<T,E> ptr = find(key, root);
    	root = deleter(ptr.value,root); 
    }

    private node<T,E> deleter(E value, node <T,E> root){
    	if(root==null){
    		return root;
    	}
    	if(value.compareTo(root.value)<0){
    		root.left=deleter(value ,root.left);
    	}
    	else if(value.compareTo(root.value)>0){
    		root.right= deleter(value, root.right);
    	}

    	else{
    		if(root.left==null){
    			return root.right;
    		}
    		else if(root.right ==null){
    			return root.left;
    		}
    		root.value=min_node(root.right).value;
    		root.key=min_node(root.right).key;
    		root.right = deleter(root.value, root.right);
    	}
    	return root;
    }


// printing in level order 
    public void printBST () {
    	if(root==null){
    		return;
    	}
    	else{
    		node<T,E> ptr;
    		node<T,E> print;
    		Queue<node> q = new LinkedList<>();
    		q.add(root);
    		while(q.size()!=0){
    			ptr = q.element();
    			if(ptr.left!= null){
    				q.add(ptr.left);
    			}
    			if(ptr.right != null){
    				q.add(ptr.right);
    			}
    			print=q.remove();
    			System.out.println(print.key + ", " + print.value);
    		}
    	}
    }



// Traverse, starting from r
    private node<T,E> min_node(node<T,E> r){
    	if(r==null){
    		return null;
    	}

    	node<T,E> min = r;
    	
    	while(r.left!=null){
    		min = r.left;
    		r = r.left;
    	}
    	return min;

    }

// Finding node for a particular key
    private node<T,E> find(T key, node<T,E> r){
    	node<T,E> ptr;
    	ptr=r;
    	Queue<node> q1 = new LinkedList<>();
    	q1.add(r);
    	if(ptr==null){
    		return null;
    	}
    	else{
    		while(q1.size()!=0)
    		{
    			node<T,E> t = q1.poll();
    			if(t.key.compareTo(key) == 0)
    			{
    				return t;
    			}
    			if(t.left!=null)
    			{
    				q1.add(t.left);
    			}
    			if(t.right!=null)
    			{
    				q1.add(t.right);
    			}
    		}
    	}
    	return ptr;
    }
}
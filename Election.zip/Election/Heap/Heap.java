package col106.assignment3.Heap;
import java.util.ArrayList;


public class Heap<T extends Comparable, E extends Comparable> implements HeapInterface <T, E> {
	/* 
	 * Do not touch the code inside the upcoming block 
	 * If anything tempered your marks will be directly cut to zero
	*/
	public static void main() {
		HeapDriverCode HDC = new HeapDriverCode();
		System.setOut(HDC.fileout());
	}
	/*
	 * end code
	 */
	
	class node<T extends Comparable, E extends Comparable>{
		T key;
		E value;
		// node left;
		// node right;

		public node(T k, E v){
			key =k;
			value=v;
			// left=null;
			// right=null;
		}
	}
	
	public ArrayList<node> heap;


	public Heap(){
		heap= new ArrayList<node>(0);
	}

	private int parenti(node<T,E> n){
		return (heap.indexOf(n)-1)/2;
	}

	private ArrayList<node> swap(int i, int j){
		node<T,E> temp = heap.get(i);
		heap.set(i,heap.get(j));
		heap.set(j,temp);
		return heap;
	}

	private ArrayList<node> percUp(node<T,E> n){
		int j=heap.indexOf(n);
		if(j==0){
			return heap;
		}
		else{
			int i = parenti(n);
			if(heap.get(i).value.compareTo(n.value)<0){
				heap=swap(i,j);
				return percUp(heap.get(i));
			}
			else{
				return heap;
			}
		}
	}

	private ArrayList<node> percDown(node<T,E> n){
		int j=heap.indexOf(n);
		node<T,E> max;
		if(2*j+1 < heap.size()){
			if(2*j+2< heap.size()){
				if(heap.get(2*j+1).value.compareTo(heap.get(2*j+2).value)>0){
					max= heap.get(2*j+1);
				}
				else{
					max=heap.get(2*j+2);
				}
				int k=heap.indexOf(max);
				if(max.value.compareTo(n.value)>0){
					heap=swap(j,k);
					return percDown(heap.get(k));
				}
				else{
					return heap;
				}
			}
			else{
				max= heap.get(2*j+1);
				int k=heap.indexOf(max);
				if(max.value.compareTo(n.value)>0){
					heap=swap(j,k);
					return percDown(heap.get(k));
				}
				else{
					return heap;
				}
			}
		}
		else{
			return heap;
		}
	}

	public void insert(T key, E value) {
		node ins = new node(key,value);
		heap.add(ins);
		if(heap.size()==1){
		}
		else{
			heap=percUp(ins);
		}
		return;
	}

	public E extractMax() {
		if(heap.size()==0){
			return null;
		}
		else{
			node<T,E> max= heap.get(0);
			E maxv = max.value;
			heap= swap(0,heap.size()-1);
			heap.remove(heap.size()-1);
			if(heap.size()>1){
				heap = percDown(heap.get(0));
			}
			return maxv;
		}
	}

	public void delete(T key){
		if(heap.size()==0){
			return;
		}
		else{
			node<T,E> temp = heap.get(0);
			int i;
			for(i=0; i<heap.size(); i++){
				if(heap.get(i).key.compareTo(key) == 0){
					temp=heap.get(i);
					break;
				}				
			}
			if(i==heap.size()-1){
				heap.remove(i);
				return;
			}
			heap= swap(heap.indexOf(temp),heap.size()-1);
			heap.remove(heap.size()-1);
			if(heap.size()>1){
				heap= percDown(heap.get(i));
			}
			return;
		}
	}

	public void increaseKey(T key, E value) {
		if(heap.size()==0){
			return;
		}
		else
		{
			node <T,E> temp=heap.get(0);
			int i;
			for(i=0; i<heap.size(); i++){
				if(heap.get(i).key.compareTo(key) == 0){
					temp= heap.get(i);
					break;
				}
				else{
					if(i == heap.size()-1){
							return;
						}
				}
			}
			temp.value=value;
			heap.set(i,temp);
			if(i==0){
				if(heap.size()>1){
				heap=percDown(heap.get(i));
				}
			}
			else{
				int j= parenti(heap.get(i));
				if(heap.get(j).value.compareTo(heap.get(i).value)>=0){
					heap=percDown(heap.get(i));
				}
				else{
					heap=percUp(heap.get(i));
				}
			}
			return;
		}
	}

	public void printHeap() {
		for (int j=0;j<heap.size();j++){
			System.out.println(heap.get(j).key + ", " + heap.get(j).value);
		}
	}	
}

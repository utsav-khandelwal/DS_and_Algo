package col106.assignment4.HashMap;

public class WordCounter {

	public WordCounter(){
	}

	public int count(String str, String word){
		int size = str.length() - word.length() +1;
		if(str.length() < word.length()){

			return 0;
		}

		HashMap<Integer> wc = new HashMap<Integer>(size);

		for(int i =0; i<size; i++){
			String subs = str.substring(i, i + word.length());
			if(wc.contains(subs)){
				int l = Integer.parseInt(wc.get(subs).toString()) + 1;
				wc.put(subs, l);
			}
			else{
				int val = 1;
				wc.put(subs, val);
			}
		}
		
		if(wc.contains(word)){
			return Integer.parseInt(wc.get(word).toString());
		}
		else{
			return 0;
		}
	}
}
package col106.assignment4.HashMap;
import java.util.Vector;
import java.util.ArrayList;

public class HashMap<V> implements HashMapInterface<V> {

	public int hashing(String key){
		int index=0;
		for(int i=key.length()-1; i>=0; i--){
			index = ((int)key.charAt(i))%hash.length + (41*index)%hash.length;
			index = index%(hash.length);
		}
		index = index%(hash.length);
		//System.out.println(index);
		return index;
	}

	private class node<V>{
		String key;
		V value;

		public node(String k, V val){
			key = k;
			value = val;
		}
	}

	private node[] hash;

	public HashMap(int size) {
		hash = new node[size];

	}

	public V put(String key, V value){

		int index = hashing(key);
		if(hash[index] == null){
			hash[index] = new node(key, value);
			return null;
		}
		else{
			node<V> ptr = hash[index];
			while(ptr!= null){
				if(key.equals(ptr.key)){
					V rem = ptr.value;
					ptr.value = value;
					return rem;
				}
				else{
					index++;
					index = index%hash.length;
					ptr= hash[index];
				}
			}
			hash[index] = new node(key, value);
			return null;
		}
	}

	public V get(String key){
		if(hash.length == 0){
			return null;
		}
		int index = hashing(key);
		node<V> ptr = hash[index];
		int counter = 0;
		while(ptr!=null && counter<=hash.length){
			if(key.equals(ptr.key)){
				return ptr.value;
			}
			else{
				index++;
				index = index%hash.length;
				ptr = hash[index];
			}
			counter++;
		}
		return null;
	}


	public boolean remove(String key){
		if(hash.length == 0){
			return false;
		}

		int index = hashing(key);
		node<V> ptr = hash[index];

		while(ptr!= null){
			if(key.equals(ptr.key)){
				hash[index] = null;
				int tempI = index+1; 
				tempI = tempI%hash.length;
				node<V> tempP = hash[tempI];
				while(tempP!=null){
					int natI = hashing(tempP.key);
					if(tempI == natI){
						tempI++;
						tempI = tempI%hash.length;
						tempP = hash[tempI];
					}
					else if(tempI< natI){
						hash[index] = tempP;
						index=tempI;
						hash[index] = null;
						tempI++;
						tempI = tempI%hash.length;
						tempP = hash[tempI];
					}
					else{
						if(natI> index){
							tempI++;
							tempI = tempI%hash.length;
							tempP = hash[tempI];
						}
						else{
							hash[index] = tempP;
							index = tempI;
							index = index % hash.length;
							hash[index] = null;
							tempI++;
							tempI = tempI % hash.length;
							tempP = hash[tempI];
						}
					}
				}
				return true;
			}
			else{
				index++;
				index = index%hash.length;
				ptr = hash[index];
			}
		}
		return false;
	}

	public boolean contains(String key){
		if(hash.length == 0){
			return false;
		}

		int index = hashing(key);
		node<V> ptr = hash[index];
		int counter = 0;
		while(ptr!=null && counter<=hash.length){
			if(key.equals(ptr.key)){
				return true;
			}
			else{
				index++;
				index = index % hash.length;
				ptr = hash[index];
			}
			counter++;
		}
		return false;
	}

	public Vector<String> getKeysInOrder(){

		Vector<String> out = new Vector<String>();

		for(int i=0; i < hash.length; i++){
			if(hash[i] != null){
				out.add(hash[i].key);
			}
		}
		return out;
	}
}
